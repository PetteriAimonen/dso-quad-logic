Baselibc
========
This is a very simple libc for embedded systems. Mainly geared for 32-bit microcontrollers in the 10-100kB memory range.

The code is based on klibc and tinyprintf modules. License is therefore GPL.
