#include <string.h>

void bzero(void *dst, size_t n)
{
	memset(dst, 0, n);
}
